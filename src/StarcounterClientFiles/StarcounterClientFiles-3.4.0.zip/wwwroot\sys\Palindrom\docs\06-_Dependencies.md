# Dependencies

It depends on Native [ES6 Proxies](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Proxy). Check usability on [caniuse](http://www.caniuse.com/#search=Proxy).

If you use the bundle, no file dependencies are needed. You can view all the dependencies in [package.json](https://github.com/Palindrom/Palindrom/blob/master/package.json).
