# Changelog

To see the list of recent changes, see [Releases](https://github.com/Palindrom/Palindrom/releases).
